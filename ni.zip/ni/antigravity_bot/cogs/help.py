import discord
from discord.ext import commands
import datetime

class HelpCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="help")
    async def help(self, ctx):
        embed = discord.Embed(
            title="🪐 Antigravity Bot Help",
            description="Defying physics and expectations since 2025.\nHere are the commands you can use:",
            color=discord.Color.from_rgb(138, 43, 226) # Blue-Violet
        )
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.set_image(url="https://media.discordapp.net/attachments/866030999557242880/1189912443468550184/standard_2.gif?ex=676fe4f8&is=676e9378&hm=468925584558e827605d83637651833503251505315053676100") # Placeholder space gif or remove

        # 🎵 Music
        embed.add_field(
            name="🎵 **Music System**",
            value=(
                "`!play <song/url>` - Play from YT/Spotify\n"
                "`!join` - Summon the bot\n"
                "`!stop` - Stop playback\n"
                "`!skip` - Skip track\n"
                "(+ Interactive Player UI)"
            ),
            inline=False
        )

        # 🛡️ Moderation
        embed.add_field(
            name="🛡️ **Moderation**",
            value=(
                "`!ban @user [reason]` - Ban user\n"
                "`!unban <id>` - Unban user\n"
                "`!kick @user` / `!yeet`\n"
                "`!mute @user <mins>` / `!timeout`\n"
                "`!purge <amount>` - Clear chat\n"
                "`!slowmode <seconds>`"
            ),
            inline=False
        )

        # 🧩 Fun & AI
        embed.add_field(
            name="🤖 **Fun & Chaos**",
            value=(
                "`!chat <msg>` - Talk to AI\n"
                "`!iq` - Check IQ\n"
                "`!roast @user` - Roast someone\n"
                "`!fortune` - Get a fortune"
            ),
            inline=False
        )

        embed.set_footer(text=f"Requested by {ctx.author.name} • {datetime.datetime.now().strftime('%Y-%m-%d')}")
        
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(HelpCog(bot))
