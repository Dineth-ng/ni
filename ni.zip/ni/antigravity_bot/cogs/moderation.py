import discord
from discord.ext import commands
import random
import datetime

class ModerationCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="yeet")
    @commands.has_permissions(kick_members=True)
    async def yeet(self, ctx, member: discord.Member, *, reason=None):
        if reason is None:
            reasons = [
                "The atmosphere was too heavy.",
                "Failed the vibe check.",
                "Gravity reversed!",
                "To infinity and beyond!",
                "Begone, thot!",
                "Sent to the shadow realm."
            ]
            reason = random.choice(reasons)
        
        try:
            await member.kick(reason=reason)
            await ctx.send(f"```text\n{member.name} was yeeted. Reason: {reason} 🚀\n```")
        except discord.Forbidden:
            await ctx.send("```text\nI tried to yeet them, but they are too heavy (Missing Permissions).\n```")

    @yeet.error
    async def yeet_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("```text\nYou don't have the power to yeet people!\n```")

    @commands.command(name="ban")
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason=None):
        if not reason: reason = "The ban hammer has spoken."
        try:
            await member.ban(reason=reason)
            await ctx.send(f"```text\n🚫 {member.name} has been banished to the Void. Reason: {reason}\n```")
        except discord.Forbidden:
             await ctx.send("```text\nI cannot ban this user (Hierarchy or Permission error).\n```")

    @commands.command(name="unban")
    @commands.has_permissions(ban_members=True)
    async def unban(self, ctx, user_id: str):
        """Unban a user by their ID."""
        try:
            user = await self.bot.fetch_user(user_id)
            await ctx.guild.unban(user)
            await ctx.send(f"```text\n✅ {user.name} returned from the event horizon.\n```")
        except Exception as e:
             await ctx.send(f"```text\nCould not unban. Ensure you provided a valid User ID. ({e})\n```")

    @commands.command(name="timeout", aliases=["mute"])
    @commands.has_permissions(moderate_members=True)
    async def timeout(self, ctx, member: discord.Member, minutes: int, *, reason="Time out"):
        """Timeout a user for X minutes."""
        try:
            duration = datetime.timedelta(minutes=minutes)
            await member.timeout(duration, reason=reason)
            await ctx.send(f"```text\n⏳ {member.name} has been frozen in time for {minutes} minutes.\n```")
        except discord.Forbidden:
            await ctx.send("```text\nI cannot timeout this user.\n```")
        except Exception as e:
            await ctx.send(f"```text\nError: {e}\n```")

    @commands.command(name="purge", aliases=["clear"])
    @commands.has_permissions(manage_messages=True)
    async def purge(self, ctx, amount: int):
        """Delete X messages."""
        if amount > 100: amount = 100
        await ctx.channel.purge(limit=amount+1) # +1 to include command
        msg = await ctx.send(f"```text\nReduced {amount} messages to atoms. ⚛️\n```")
        await msg.delete(delay=3)

    @commands.command(name="slowmode")
    @commands.has_permissions(manage_channels=True)
    async def slowmode(self, ctx, seconds: int):
        """Set channel slowmode."""
        await ctx.channel.edit(slowmode_delay=seconds)
        if seconds > 0:
            await ctx.send(f"```text\nTime dilation activated: {seconds} seconds.\n```")
        else:
             await ctx.send(f"```text\nTime flows normally again.\n```")

    @commands.command(name="silence")
    @commands.has_permissions(move_members=True)
    async def silence(self, ctx, member: discord.Member):
        """Disconnects a user from voice channel."""
        if member.voice and member.voice.channel:
            try:
                await member.move_to(None)
                await ctx.send(f"```text\n{member.name} has been silenced. 🤫\n```")
            except discord.Forbidden:
                await ctx.send("```text\nI can't disconnect them (Missing Permissions).\n```")
        else:
            await ctx.send(f"```text\n{member.name} is not in a voice channel.\n```")

async def setup(bot):
    await bot.add_cog(ModerationCog(bot))

    @commands.command(name="yeet")
    @commands.has_permissions(kick_members=True)
    async def yeet(self, ctx, member: discord.Member, *, reason=None):
        if reason is None:
            reasons = [
                "The atmosphere was too heavy.",
                "Failed the vibe check.",
                "Gravity reversed!",
                "To infinity and beyond!",
                "Begone, thot!",
                "Sent to the shadow realm."
            ]
            reason = random.choice(reasons)
        
        try:
            await member.kick(reason=reason)
            await ctx.send(f"```text\n{member.name} was yeeted. Reason: {reason} 🚀\n```")
        except discord.Forbidden:
            await ctx.send("```text\nI tried to yeet them, but they are too heavy (Missing Permissions).\n```")

    @yeet.error
    async def yeet_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("```text\nYou don't have the power to yeet people!\n```")

    @commands.command(name="silence")
    @commands.has_permissions(move_members=True)
    async def silence(self, ctx, member: discord.Member):
        """Disconnects a user from voice channel."""
        if member.voice and member.voice.channel:
            try:
                await member.move_to(None)
                await ctx.send(f"```text\n{member.name} has been silenced. 🤫\n```")
            except discord.Forbidden:
                await ctx.send("```text\nI can't disconnect them (Missing Permissions).\n```")
        else:
            await ctx.send(f"```text\n{member.name} is not in a voice channel.\n```")

async def setup(bot):
    await bot.add_cog(ModerationCog(bot))
